#include "pregunta_3.h"

int frecuencia_de_una_nota(nodo* raiz, int nota) { return 0; }