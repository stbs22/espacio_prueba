#include "tree.h"

int nota_mas_frecuente(nodo* raiz);