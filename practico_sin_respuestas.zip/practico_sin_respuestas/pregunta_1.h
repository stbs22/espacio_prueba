#include "tree.h"

int profundidad(nodo *raiz);