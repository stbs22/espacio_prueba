#include "tree.h"

int frecuencia_de_una_nota(nodo* raiz, int nota);