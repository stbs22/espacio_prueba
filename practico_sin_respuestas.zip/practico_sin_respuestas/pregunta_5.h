#include "tree.h"

int nota_mas_frecuente_2(nodo* raiz, int* nota_frecuente);