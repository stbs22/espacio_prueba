#include "pregunta_2.h"

int cantidad_alumnos(nodo* raiz) { return 0; }