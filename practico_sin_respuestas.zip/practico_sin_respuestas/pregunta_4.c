#include "pregunta_4.h"

int nota_mas_frecuente(nodo* raiz) { return 0; }