#include "tree.h"

int cantidad_alumnos(nodo* raiz);