#include "pregunta_1.h"

int profundidad(nodo *raiz) { return 0; }